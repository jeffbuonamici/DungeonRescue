﻿using UnityEngine;
using System.Collections;

public class CameraFollow : MonoBehaviour
{
    [SerializeField]
    Transform mTarget;

    float followSpeed = 5f;
    float stepOverThreshold = 0.05f;

    Vector3 targetPosition;
    Vector3 direction;

    void Update ()
    {
        if(mTarget != null)
        {
            if (mTarget.transform.position.x < -11 || mTarget.transform.position.x > 11)
            {
                targetPosition = new Vector3(transform.position.x, transform.position.y, transform.position.z);
                direction = targetPosition - transform.position;
            }
            else
            {
                targetPosition = new Vector3(mTarget.transform.position.x, transform.position.y, transform.position.z);
                direction = targetPosition - transform.position;
            }
           
            
            if(direction.magnitude > stepOverThreshold)
            {
                transform.Translate (direction.normalized * followSpeed * Time.deltaTime);
            }
            else
            {
                transform.position = targetPosition;
            }
        }
    }
}
