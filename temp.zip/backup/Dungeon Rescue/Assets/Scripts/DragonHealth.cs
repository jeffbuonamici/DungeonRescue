﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DragonHealth : MonoBehaviour {

    int healthPoint = 10;
    
    // Use this for initialization
    void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
        if (healthPoint == 0)
        {
            Destroy(gameObject);
        }
    }
    public void loseHealth(int dmg)
    {
        healthPoint -= dmg;
    }
}
