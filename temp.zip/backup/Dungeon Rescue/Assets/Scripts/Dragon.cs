﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Dragon : MonoBehaviour {

	[SerializeField]
	Transform mTarget;
	[SerializeField]
	float mFollowSpeed;
	[SerializeField]
	float mAggroRange;
	[SerializeField]
	float mIdleRange;
	[SerializeField]
	float mCloseRange;

    [SerializeField]
    GameObject mfireBreathPrefab;

    [SerializeField]
    GameObject mPotionPrefab;

    GameObject potion;

    // [SerializeField]
    // DragonHealth life;

    float fireBreathTimer=0;

    public float attackDelay;
	float cooldownTimer = 0f;

	bool isWalking;
	bool isAttacking;

    int healthPoint = 5;

    GameObject fireBreath;
    // Use this for initialization
    void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		cooldownTimer -= Time.deltaTime;
		if(mTarget != null)
		{
			if ((Vector2.Distance (transform.position, mTarget.transform.position) < mAggroRange) 
				&& !(Vector2.Distance (transform.position, mTarget.transform.position) < mIdleRange)) {
				transform.position += (mTarget.transform.position - transform.position).normalized * Time.deltaTime;
				isWalking = true;
			}
			if (Vector2.Distance (transform.position, mTarget.transform.position) < mCloseRange) {
				transform.position -= (mTarget.transform.position - transform.position).normalized * Time.deltaTime;
				isWalking = true;
			}
			if ((Vector2.Distance (transform.position, mTarget.transform.position) < mAggroRange)
				&& cooldownTimer <= 0) {
				if (DetermineAttack() < 4)
					Attack ();
				else 
					cooldownTimer = attackDelay;
			}
		}

        if (fireBreath != null)
        {
            fireBreathTimer += Time.deltaTime;
            fireBreath.transform.position = new Vector3(transform.position.x - 4, transform.position.y + 0.6f);
            if (fireBreathTimer > 1)
            {
                Destroy(fireBreath);
                fireBreathTimer = 0;
            }
        }

        isWalking = false;
		isAttacking = false;

        if (healthPoint < 1)
        {
            Destroy(gameObject);
            for (int i = 0; i < 2; i++)
            {
                potion = Instantiate(mPotionPrefab, new Vector3(transform.position.x - 0.1f, transform.position.y + 0.5f), Quaternion.identity);
                potion.name = "potion";
            }
        }
	}

	int DetermineAttack() {
		System.Random rnd = new System.Random ();
		int value = rnd.Next (1, 10);
		return value;
	}

	void Attack() {
		cooldownTimer = attackDelay;
		isAttacking = true;
		Debug.Log ("Attack!");
        fireBreath = Instantiate(mfireBreathPrefab, new Vector3(transform.position.x-4, transform.position.y+0.6f), Quaternion.identity);
       
    }

    public void TakeDamage(int dmg)
    {
        healthPoint -= dmg;
    }
}
